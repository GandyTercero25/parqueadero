import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Parqueadero parqueadero = new Parqueadero(40); // Crear parqueadero con 40 puestos


        while (true) {
            System.out.println("\n----- Parqueadero -----\n");
            System.out.println("1. Ingresar un carro");
            System.out.println("2. Dar salida a un carro");
            System.out.println("3. Informar los ingresos");
            System.out.println("4. Consultar puestos disponibles");
            System.out.println("5. Avanzar el reloj del parqueadero");
            System.out.println("6. Cambiar la tarifa del parqueadero");
            System.out.println("7. Salir");

            System.out.print("\nIngrese una opción: ");
            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    ingresarCarro(scanner, parqueadero);
                    break;
                case 2:
                    darSalidaCarro(scanner, parqueadero);
                    break;
                case 3:
                    informarIngresos(parqueadero);
                    break;
                case 4:
                    consultarPuestosDisponibles(parqueadero);
                    break;
                case 5:
                    avanzarReloj(scanner, parqueadero);
                    break;
                case 6:
                    cambiarTarifa(scanner, parqueadero);
                    break;
                case 7:
                    System.out.println("¡Hasta luego!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        }
    }

    private static void ingresarCarro(Scanner scanner, Parqueadero parqueadero) {
        System.out.print("\nIngrese la placa del carro: ");
        String placa = scanner.next();
        System.out.print("Ingrese la hora de entrada (formato HH:mm): ");
        String horaEntradaStr = scanner.next();

        boolean ingresoExitoso = parqueadero.ingresarCarro(placa, horaEntradaStr);

        if (ingresoExitoso) {
            System.out.println("Carro ingresado exitosamente al parqueadero.");
        } else {
            System.out.println("El parqueadero está lleno. No se puede ingresar el carro.");
        }
    }

    private static void darSalidaCarro(Scanner scanner, Parqueadero parqueadero) {
        System.out.print("\nIngrese la placa del carro: ");
        String placa = scanner.next();
        System.out.print("Ingrese la hora de salida (formato HH:mm): ");
        String horaSalidaStr = scanner.next();

        double totalAPagar = parqueadero.darSalidaCarro(placa, horaSalidaStr);

        if (totalAPagar >= 0) {
            System.out.println("Carro salido del parqueadero.");
            System.out.println("Total a pagar: $" + totalAPagar);
        } else {
            System.out.println("No se encontró el carro en el parqueadero.");
        }
    }

    private static void informarIngresos(Parqueadero parqueadero) {
        double ingresos = parqueadero.obtenerIngresos();
        System.out.println("\nIngresos del parqueadero: $" + ingresos);
    }
    private static void consultarPuestosDisponibles(Parqueadero parqueadero) {
        int puestosDisponibles = parqueadero.obtenerPuestosDisponibles();
        System.out.println("\nPuestos disponibles: " + puestosDisponibles);
    }

    private static void avanzarReloj(Scanner scanner, Parqueadero parqueadero) {
        System.out.print("\nIngrese la cantidad de horas a avanzar: ");
        int horasAvanzar = scanner.nextInt();

        parqueadero.avanzarReloj(horasAvanzar);
        System.out.println("Reloj del parqueadero avanzado " + horasAvanzar + " horas.");
    }

    private static void cambiarTarifa(Scanner scanner, Parqueadero parqueadero) {
        System.out.print("\nIngrese la nueva tarifa por hora: ");
        double nuevaTarifa = scanner.nextDouble();

        parqueadero.cambiarTarifa((int) nuevaTarifa);
        System.out.println("Tarifa del parqueadero cambiada exitosamente.");
    }
}